Idealizado por Flávio Lucas, o programa de Controle Escolar visa otimizar a gestão educacional, buscando facilitar o dia a dia de escolas e instituições de ensino, simplificando tarefas e otimizando processos.

Com o objetivo de aprimorar ainda mais o projeto, Flávio Lucas deu início à Pós-Graduação FullStack Unyleya. 
